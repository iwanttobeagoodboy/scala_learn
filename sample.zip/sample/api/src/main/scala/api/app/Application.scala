package api.app

import java.awt.Component
import java.beans.PropertyChangeListener
import java.io.File


trait Application {
  def launch(args: Array[String]): Unit
  def configure(arg: Array[String]): Unit
  def init(): Unit
  def start(): Unit
  def stop(): Unit
  def add(p: Project): Unit
  def remove(p: Project): Unit
  def show(p: Project): Unit
  def hide(p: Project): Unit
  def dispose(p: Project): Unit
  def projects: List[Project]
  def isEnable: Boolean
  def setEnable(newValue: Boolean): Unit
  def addPropertyChangeListener(l: PropertyChangeListener): Unit
  def removePropertyChangeListener(l: PropertyChangeListener): Unit
  def getName: String
  def getVersion: String
  def getCopyright: String
  def getModel: ApplicationModel
  def setModel(model: ApplicationModel): Unit
  def isSHaringToolsAmongProjects: Boolean
  def getComponent: Component
  def recentFiles: List[File]
  def addRecentFile(file: File): Unit
  def cleanRecentFiles(): Unit
}