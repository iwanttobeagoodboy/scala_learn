package api.app

trait EditableComponent {
  def copy(): Unit
  def cut(): Unit
  def delete(): Unit
  def paste(): Unit
  def duplicate(): Unit
  def selectAll(): Unit
}
