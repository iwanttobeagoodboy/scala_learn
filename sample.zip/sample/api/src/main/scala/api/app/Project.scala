package api.app

import java.beans.PropertyChangeListener
import java.io.File

import javax.swing._

trait Project {
  def getApplication: Application
  def setApplication(newValue: Application): Unit
  def getComponent: JComponent
  def getFile: File
  def setFile(newValue: File): Unit
  def isEnabled: Boolean
  def setEnabled(newValue: Boolean): Unit
  def write(f: File): Unit
  def read(f: File): Unit
  def clear(): Unit
  def getOpenChooser: JFileChooser
  def getSaveChooser: JFileChooser
  def hasUnsavedChanges: Boolean
  def markChangeAsSaved(): Unit
  def execute(worker: Runnable): Unit
  def init(): Unit
  def dispose(): Unit
  def getAction(id: String): Action
  def putAction(id: String, action: Action): Unit
  def addPropertyChangeListener(l: PropertyChangeListener): Unit
  def removePropertyChangeListener(l: PropertyChangeListener): Unit
  def isShowing: Boolean
  def setShowing(newValue: Boolean): Unit
}
