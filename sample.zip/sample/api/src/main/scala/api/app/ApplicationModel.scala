package api.app

import javax.swing._

trait ApplicationModel {
  def getName: String
  def getVersion: String
  def getCopyright: String
  def putAction(id: String, action: Action): Unit
  def getAction(id: String): Action
  def createToolBars(a: Application, p: Project): List[JToolBar]
  def createMenus(a: Application, p: Project): List[JMenu]
}
