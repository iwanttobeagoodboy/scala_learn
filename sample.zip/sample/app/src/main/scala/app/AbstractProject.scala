package app

import api.app._
import java.awt.BorderLayout
import java.io.File
import java.util.concurrent.{Executor, Executors}
import java.util.prefs.Preferences

import javax.swing.{Action, JComponent, JFileChooser, JPanel}

abstract class AbstractProject extends JPanel with Project {
  private var application: Application = _
  private var saveChooser: JFileChooser = _
  private var openChooser: JFileChooser = _
  protected var file: File = _
  protected var executor: Executor = _
  private val actions: collection.mutable.Map[String, Action] = collection.mutable.Map()
  private var _hasUnsavedChanges: Boolean = _
  private var prefs: Preferences = _
  private var _isShowing: Boolean = _

  def init(): Unit = {
    prefs = Preferences.userNodeForPackage(getClass)
    initComponents()
  }
  private def initComponents(): Unit = {
    setLayout(new BorderLayout())
  }
  override def setApplication(newValue: Application): Unit = {
    val oldValue = application
    application = newValue
    firePropertyChange("application", oldValue, newValue)
  }
  override def getApplication: Application = application
  override def getComponent: JComponent = this
  override def getFile: File = file
  override def setFile(newValue: File): Unit = {
    val oldValue = file
    file = newValue
    if (prefs != null && newValue != null) {
      prefs.put("projectFiile", newValue.getPath)
    }
    firePropertyChange("file", oldValue, newValue)
  }
  override def getOpenChooser: JFileChooser = {
    if (openChooser == null) {
      openChooser = createOpenChooser
    }
    openChooser
  }
  protected def createOpenChooser: JFileChooser = {
    val c = new JFileChooser()
    if (prefs != null) {
      c.setSelectedFile(new File(prefs.get("projectFile", System.getProperty("user.home"))))
    }
    c
  }
  override def getSaveChooser: JFileChooser = {
    if (saveChooser == null) {
      saveChooser = createSaveChooser
    }
    saveChooser
  }
  protected def createSaveChooser: JFileChooser = {
    val c = new JFileChooser()
    if (prefs != null) {
      c.setSelectedFile(new File(prefs.get("projectFile", System.getProperty("user.home"))))
    }
    c
  }
  override def hasUnsavedChanges: Boolean = _hasUnsavedChanges
  protected def setHasUnsavedChanges(newValue: Boolean): Unit = {
    val oldValue = _hasUnsavedChanges
    _hasUnsavedChanges = newValue
    firePropertyChange("hasUnsavedChanges", oldValue, newValue)
  }
  override def dispose(): Unit = { }
  override def getAction(id: String): Action = actions.getOrElse(id, null)
  override def putAction(id: String, action: Action): Unit = {
    if (action == null) {
      actions.remove(id)
    } else {
      actions.put(id, action)
    }
  }
  override def execute(worker: Runnable): Unit = {
   if (executor == null) {
     executor = Executors.newSingleThreadExecutor()
   }
    executor.execute(worker)
  }
  override def isShowing: Boolean = _isShowing
  override def setShowing(newValue: Boolean): Unit = {
    val oldValue = _isShowing
    _isShowing = newValue
    firePropertyChange("showing", oldValue, newValue)
  }
  override def markChangeAsSaved(): Unit = setHasUnsavedChanges(false)
}

