package app

import api.app._
import java.awt.event.ActionEvent
import java.awt.{Color, Component, Dimension}

import javax.swing._

class MDIApplication extends AbstractApplication {
  private val parentFrame: JFrame = new JFrame()
  private val rootPane: JPanel = new JPanel()
  private val mainPane: JPanel = new JPanel()
  private val sidePane: JPanel = new JPanel()
  private var currentProject: Project = _

  override def init(): Unit = {
    super.init()
    // set mainPane and side Pane outLook
    sidePane.setBackground(new Color(53, 46, 199))
    sidePane.setPreferredSize(new Dimension(50, 400))
    sidePane.add(new JButton("hello"))
    mainPane.setPreferredSize(new Dimension(550, 400))
    mainPane.add(new JLabel("welcome"))
    rootPane.setLayout(new BoxLayout(rootPane, BoxLayout.X_AXIS))
    rootPane.add(sidePane)
    rootPane.add(mainPane)
    rootPane.setPreferredSize(new Dimension(600, 400))
    parentFrame.add(rootPane)
    parentFrame.pack()
  }
  override def start(): Unit = {
    parentFrame.setVisible(true)
  }
  protected def initApplicationAction(): Unit = {
    // put Action to model
    println("application add action to model")
    val model = getModel
    model.putAction("New", new AbstractAction() {
      override def actionPerformed(e: ActionEvent): Unit = println("New")
    })
    model.putAction("Exit", new AbstractAction() {
      override def actionPerformed(e: ActionEvent): Unit = println("Exit")
    })
    // other action
  }
  override protected def initProjectActions(p: Project): Unit = {
    // project add action
    println("project add action")
    p.putAction("Focus", new AbstractAction() {
      override def actionPerformed(e: ActionEvent): Unit = {
        println("focus action")
      }
    })
  }

  override def show(p: Project): Unit = {
    hide(currentProject)
   if (!p.isShowing) {
     p.getComponent.setVisible(true)
     p.setShowing(true)
   }
    setCurrentProject(p)
  }

  override def hide(p: Project): Unit = {
    if (p != null) {
      if (p.isShowing) {
        p.getComponent.setVisible(false)
        p.setShowing(false)
      }
      if (currentProject == p) {
        currentProject = null
      }
    }
  }

  def getCurrentProject: Project = currentProject

  def setCurrentProject(newValue: Project): Unit = {
    val oldValue = currentProject
    currentProject = newValue
    firePropertyChange("currentProject", oldValue, newValue)
  }

  override def isSHaringToolsAmongProjects: Boolean = true

  override def getComponent: Component = parentFrame

}
