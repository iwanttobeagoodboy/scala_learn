package app

import api.app._
import java.awt.Container
import java.io.File
import java.util.prefs.Preferences

import bean.AbstractBean
import javax.swing.{JFrame, SwingUtilities}
import util.ResourceBundleUtil

import scala.collection.mutable.ListBuffer

abstract class AbstractApplication() extends AbstractBean with Application {
  private val _projects: ListBuffer[Project] = ListBuffer.empty[Project]
  private val unmodifiableDocuments: ListBuffer[Project] = ListBuffer.empty
  private var _isEnable: Boolean = true
  protected var labels: ResourceBundleUtil = _
  private var model: ApplicationModel = _
  private val _recentFiles: ListBuffer[File] = ListBuffer.empty[File]
  private var maxRecentFileCount: Int = 10;
  private var prefs: Preferences = _

  def init(): Unit = {
    val model = if (getModel == null) getClass else getModel.getClass
    prefs = Preferences.userNodeForPackage(model)

    val count = prefs.getInt("recentFileCount", 0)
    (0 until count).foreach(i => {
      val path: String = prefs.get(s"recentFile.$i", null)
      if (path != null) {
        _recentFiles += new File(path)
      }
    })
  }

  override def setModel(newValue: ApplicationModel): Unit = {
    val oldValue = model
    model = newValue
    firePropertyChange("model", oldValue, newValue)
  }
  override def getModel: ApplicationModel = model
  override def getName: String = model.getName
  override def getVersion: String = model.getVersion
  override def getCopyright: String = model.getCopyright
  protected def initProjectActions(p: Project)
  override def stop(): Unit = {
    projects.foreach(dispose)
    System.exit(0)
  }
  override def remove(p: Project): Unit = {
    hide(p)
    val oldCount = projects.size
    _projects -= p
    p.setApplication(null)
    firePropertyChange("projectCount", oldCount, projects.size)
  }
  override def add(p: Project): Unit = {
    if (p.getApplication != this) {
      val oldCount = projects.size
      _projects += p
      p.setApplication(this)
      firePropertyChange("projectCount", oldCount, projects.size)
    }
  }
  override def dispose(p: Project): Unit = {
    remove(p)
    p.dispose()
  }
  override def projects: List[Project] = {
    if (unmodifiableDocuments.isEmpty) _projects.toList
    else unmodifiableDocuments.toList
  }
  override def isEnable: Boolean = _isEnable
  override def setEnable(newValue: Boolean): Unit = {
    val oldValue = isEnable
    _isEnable = newValue
    firePropertyChange("enable", oldValue, newValue)
  }
  def createContainer: Container = new JFrame()
  override def launch(args: Array[String]): Unit = {
    configure(args)
    SwingUtilities.invokeLater(new Runnable {
      override def run(): Unit = {
        init()
        start()
      }
    })
  }
  protected def initLabels(): Unit = {
    labels = ResourceBundleUtil.getLAFBundle("app.Labels")
  }
  override def configure(arg: Array[String]): Unit = {}
  override def recentFiles: List[File] = _recentFiles.toList
  override def cleanRecentFiles(): Unit = {
    val oldValue = _recentFiles.toList
    prefs.putInt("recentFileCount", oldValue.size)
    firePropertyChange("recentFiles", oldValue, recentFiles)
  }
  override def addRecentFile(file: File): Unit = {
    val oldValue = recentFiles
    if (oldValue.contains(file)) {
      _recentFiles -= file
    }
    _recentFiles += file
    if (_recentFiles.size > maxRecentFileCount) {
      _recentFiles.remove(_recentFiles.size - 1)
    }
    prefs.putInt("recentFileCount", _recentFiles.size)
    _recentFiles.indices.foreach(i => {
      val f = recentFiles(i)
      prefs.put(s"recentFile.$i", f.getPath)
    })
    firePropertyChange("recentFiles", oldValue, 0)
    firePropertyChange("recentFiles", oldValue, recentFiles)
  }
}
