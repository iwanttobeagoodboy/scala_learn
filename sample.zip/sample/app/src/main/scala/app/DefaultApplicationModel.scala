package app

import api.app.{Application, ApplicationModel, Project}
import bean.AbstractBean
import javax.swing.{Action, JMenu, JToolBar}

import scala.collection.mutable.{Map => MutalMap}

class DefaultApplicationModel extends AbstractBean with ApplicationModel {
  private val actions: MutalMap[String, Action] = MutalMap()
  private var _name: String = _
  private var _version: String = _
  private var _copyright: String = _


  override def getName: String = _name
  def setName(newValue: String): Unit = {
    val oldValue = _name
    _name = newValue
    firePropertyChange("name", oldValue, newValue)
  }
  override def getVersion: String = _version
  def setVersion(newValue: String): Unit = {
    val oldValue = _version
    _version = newValue
    firePropertyChange("version", oldValue, newValue)
  }
  override def getCopyright: String = _copyright
  def setCopyright(newValue: String): Unit = {
    val oldValue = _copyright
    _copyright = newValue
    firePropertyChange("copyright", oldValue, newValue)
  }

  override def putAction(id: String, action: Action): Unit = {
    if (action == null) {
      actions.remove(id)
    } else {
      actions.put(id, action)
    }
  }
  override def getAction(id: String): Action = actions.get(id).orNull
  override def createToolBars(a: Application, p: Project): List[JToolBar] = {
    List.empty[JToolBar]
  }
  override def createMenus(a: Application, p: Project): List[JMenu] = {
    List.empty[JMenu]
  }

}
