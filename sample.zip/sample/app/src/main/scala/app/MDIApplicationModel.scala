package app

import api.app._
import javax.swing.JMenu

class MDIApplicationModel(application: MDIApplication) extends DefaultApplicationModel {

}
