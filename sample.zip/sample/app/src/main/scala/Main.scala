import app.{DefaultApplicationModel, MDIApplication, MDIApplicationModel}

object Main {
  def main(args: Array[String]): Unit = {
    val app = new MDIApplication()
    val model = new MDIApplicationModel(app)
    model.setName("mode")
    model.setVersion("0.1")
    model.setCopyright("")
    app.setModel(model)
    app.launch(args)
  }

}
