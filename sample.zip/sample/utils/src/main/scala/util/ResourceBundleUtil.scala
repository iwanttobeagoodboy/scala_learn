package util

import java.util._
import javax.swing._

// 国际化的工具
class ResourceBundleUtil(private val resource: ResourceBundle) {
  private var baseClass: Class[_] = getClass

  def getBundle: ResourceBundle = this.resource
  def getString(key: String): String = {
    try {
      resource.getString(key)
    } catch {
      //case _: MissingResourceException => key
      case _: Throwable => key
    }
  }
  def getInt(key: String): Int = {
    try {
      resource.getString(key).toInt
    } catch {
      //case _: MissingResourceException => -1
      case _: Throwable => -1
    }
  }
  def getImageIcon(key: String, baseClass: Class[_]): ImageIcon = ???
  def getMnemonic(key: String): Char = ???
  def getMnem(key: String): Char = ???
  def getTip(key: String): String = ???
  def getKeyStorke(key: String): KeyStroke = ???
  def getAcc(key: String): KeyStroke = ???
  def getFormatted(key: String, argument: String): String = ???
  def setBaseClass(baseClass: Class[_]): Unit = this.baseClass = baseClass
  def getBaseClass: Class[_] = this.baseClass
  def configureAction(action: Action, argument: String): Unit = {
    configureAction(action, argument, getBaseClass)
  }
  def configureAction(action: Action, argument: String, baseClass: Class[_]): Unit = {
    action.putValue(Action.NAME, getString(argument))
    action.putValue(Action.ACCELERATOR_KEY, getAcc(argument))
    action.putValue(Action.MNEMONIC_KEY, getMnem(argument).toInt)
    action.putValue(Action.SMALL_ICON, getImageIcon(argument, baseClass))
  }
  def configureButton(button: AbstractButton, argument: String): Unit = {
    configureButton(button, argument, getBaseClass)
  }
  def configureButton(button: AbstractButton, argument: String, baseClass: Class[_]): Unit = {
    button.setText(getString(argument))
    button.setIcon(getImageIcon(argument, baseClass))
    button.setToolTipText(getTip(argument))
  }
  def configureToolBarButton(button: AbstractButton, argument: String): Unit = {
    configureToolBarButton(button, argument, getBaseClass)
  }
  def configureToolBarButton(button: AbstractButton, argument: String, baseClass: Class[_]): Unit = {
    button.setText(getString(argument))
    button.setIcon(getImageIcon(argument, baseClass))
    button.setToolTipText(getTip(argument))
  }
  def configureMenu(menu: JMenuItem, argument: String): Unit = {
    menu.setText(getString(argument))
    menu match {
      case m: JMenu => m.setAccelerator(getAcc(argument))
    }
    menu.setMnemonic(getMnem(argument))
  }
}

object ResourceBundleUtil {
  @throws
  def getLAFBundle(baseName: String): ResourceBundleUtil = {
    getLAFBundle(baseName, LocaleUtil.getDefault)
  }
  @throws
  def getLAFBundle(baseName: String, local: Locale): ResourceBundleUtil = {
    try {
      return new ResourceBundleUtil(ResourceBundle.getBundle(s"baseName_${UIManager.getLookAndFeel.getID}", local))
    } catch {
      case e: MissingResourceException =>
        return new ResourceBundleUtil(ResourceBundle.getBundle(baseName, local))
    }
    null
  }
}
