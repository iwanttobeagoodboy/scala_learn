package util

import java.util.Locale

object LocaleUtil {
  private var defaultLocale: Locale = _
  def setDefault(newValue: Locale): Unit = defaultLocale = newValue
  def getDefault: Locale = {
    if (defaultLocale == null) Locale.getDefault()
    else defaultLocale

  }
}
