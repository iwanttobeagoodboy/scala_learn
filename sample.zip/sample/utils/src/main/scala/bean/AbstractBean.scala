package bean

import java.beans._

class AbstractBean extends Object with Serializable with Cloneable {
  protected var propertySupport: PropertyChangeSupport = new PropertyChangeSupport(this)

  def addPropertyChangeListener(listener: PropertyChangeListener): Unit = {
    propertySupport.addPropertyChangeListener(listener)
  }
  def addPropertyChangeListener(propertyName: String, listener: PropertyChangeListener): Unit = {
    propertySupport.addPropertyChangeListener(propertyName, listener)
  }
  def removePropertyChangeListener(listener: PropertyChangeListener): Unit = {
    propertySupport.removePropertyChangeListener(listener)
  }
  def removePropertyChangeListener(propertyName: String, listener: PropertyChangeListener): Unit = {
    propertySupport.removePropertyChangeListener(propertyName, listener)
  }
  def firePropertyChange(propertyName: String, oldValue: Boolean, newValue: Boolean): Unit = {
    propertySupport.firePropertyChange(propertyName, oldValue, newValue)
  }
  def firePropertyChange(propertyName: String, oldValue: Int, newValue: Int): Unit = {
    propertySupport.firePropertyChange(propertyName, oldValue, newValue)
  }
  def firePropertyChange(propertyName: String, oldValue: Any, newValue: Any): Unit = {
    propertySupport.firePropertyChange(propertyName, oldValue, newValue)
  }

  override def clone(): AbstractBean = {
    try {
      val that = super.clone().asInstanceOf[AbstractBean]
      that.propertySupport = new PropertyChangeSupport(that)
      return that
    } catch {
      case ex: CloneNotSupportedException =>
        val error = new InternalError("Clone failed")
        error.initCause(ex)
        throw error
      case _: Throwable =>
    }
    null
  }

}
